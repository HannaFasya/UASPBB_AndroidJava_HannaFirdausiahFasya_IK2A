package hanna.ppb.uas_ppb;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    CardView makanan;
    CardView rumahDapur;
    CardView IbuAnak;
    CardView Kesehatan;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        makanan = findViewById(R.id.makanan);
        rumahDapur = findViewById(R.id.rumah_dan_dapur);
        IbuAnak = findViewById(R.id.ibu_dan_anak);
        Kesehatan = findViewById(R.id.kesehatan_);

        makanan.setOnClickListener(v -> startActivity(new Intent(MainActivity.this,MakananActivity.class)));

        rumahDapur.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, RumahDapurActivity.class)));

        IbuAnak.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, IbuAnakActivity.class)));

        Kesehatan.setOnClickListener(v -> startActivity(new Intent (MainActivity.this, KesehatanActivity.class)));

        ImageView lefticon = findViewById(R.id.back_icon);
        ImageView righticon = findViewById(R.id.menu_icon);
        TextView title =findViewById(R.id.toolbar_title);

        lefticon.setOnClickListener(v -> Toast.makeText(MainActivity.this,"Menu", Toast.LENGTH_LONG).show());

        righticon.setOnClickListener(v -> Toast.makeText(MainActivity.this,"Kembali", Toast.LENGTH_LONG).show());

        title.setText("Hanna Mart");

    }
}