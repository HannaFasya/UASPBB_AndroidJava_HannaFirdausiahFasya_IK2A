package hanna.ppb.uas_ppb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RumahDapurActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rumah_dapur);
    }
}