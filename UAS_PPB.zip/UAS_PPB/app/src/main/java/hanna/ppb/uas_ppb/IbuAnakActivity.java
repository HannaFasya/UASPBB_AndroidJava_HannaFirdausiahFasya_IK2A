package hanna.ppb.uas_ppb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class IbuAnakActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ibu_anak);
    }
}